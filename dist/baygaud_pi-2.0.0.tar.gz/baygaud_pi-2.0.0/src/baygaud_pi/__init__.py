#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# baygaud 
#..........#

#|-----------------------------------------|
#| __init__.py
#|-----------------------------------------|
#| by Se-Heon Oh
#| Dept. of Physics and Astronomy
#| Sejong University, Seoul, South Korea
#|-----------------------------------------|


from ._version import __version__

#-- END OF SUB-ROUTINE____________________________________________________________#
