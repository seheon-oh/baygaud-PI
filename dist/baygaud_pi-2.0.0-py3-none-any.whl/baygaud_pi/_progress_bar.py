#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#|-----------------------------------------|
#| _progress_bar.py
#|-----------------------------------------|
#| by Se-Heon Oh
#| Dept. of Physics and Astronomy
#| Sejong University, Seoul, South Korea
#|-----------------------------------------|


import matplotlib
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import time, sys, os, math

#  _____________________________________________________________________________  #
# [_____________________________________________________________________________] #
# re-defining plotting defaults
from matplotlib import rcParams
rcParams.update({'xtick.major.pad': '7.0'})
rcParams.update({'xtick.major.size': '7.5'})
rcParams.update({'xtick.major.width': '1.5'})
rcParams.update({'xtick.minor.pad': '7.0'})
rcParams.update({'xtick.minor.size': '3.5'})
rcParams.update({'xtick.minor.width': '1.0'})
rcParams.update({'ytick.major.pad': '7.0'})
rcParams.update({'ytick.major.size': '7.5'})
rcParams.update({'ytick.major.width': '1.5'})
rcParams.update({'ytick.minor.pad': '7.0'})
rcParams.update({'ytick.minor.size': '3.5'})
rcParams.update({'ytick.minor.width': '1.0'})
rcParams.update({'font.size': 30})

#-- END OF SUB-ROUTINE____________________________________________________________#



def _fmt_ddhhmmss(seconds: float) -> str:
    """초 → dd:hh:mm:ss (음수/NaN/inf 방지 포함)"""
    if not (seconds == seconds) or seconds < 0:  # NaN 또는 음수
        seconds = 0.0
    days = int(seconds // 86400)
    seconds -= days * 86400
    hours = int(seconds // 3600)
    seconds -= hours * 3600
    minutes = int(seconds // 60)
    seconds = int(seconds - minutes * 60)
    return f"{days:02d}:{hours:02d}:{minutes:02d}:{seconds:02d}"





def _render_bar_classic(pct: float, width: int = 90, divisions: int = 20) -> str:
    """
    균등 눈금 진행바.
    - 내부 길이 L = inner-1 이 divisions의 배수가 되도록 width를 상향 스냅(ceil).
    - 눈금(:)은 정확히 L/divisions 간격으로 배치 → 완전 균등.
    """
    pct = max(0.0, min(1.0, pct))

    # 요청 폭을 가장 가까운 '균등 폭'으로 상향 스냅: inner = n*divisions + 1
    inner_req = max(10, width)
    n = max(1, math.ceil((inner_req - 1) / divisions))
    inner = n * divisions + 1   # => (inner-1) % divisions == 0
    last  = inner - 1           # 화살표 '>' 위치 후보 (0..last)

    # 눈금 배치: 정확히 L/divisions 간격
    L = last                    # 채움에 쓰는 유효 길이 (눈금/채움 모두 이 길이 기준)
    buf = [' '] * inner
    step = L // divisions       # 정수, 균등 간격
    for k in range(1, divisions):       # 0%/100% 제외
        p = k * step             # 0< p < L
        if 0 <= p < last:
            buf[p] = ':'

    # 채움(’-’)과 화살표(’>’) 배치
    filled = int(pct * L)        # 0..L
    end = min(filled, last)
    for i in range(end):
        if buf[i] == ' ':
            buf[i] = '-'
    buf[min(filled, last)] = '>'

    return "|" + "".join(buf) + "|"





def _print_progress_classic(done: int, total: int, t0: float,
                             cur_i=None, cur_j0=None, cur_j1=None,
                             state=[None, 0.0, 0.0, 0.0, 0, False, 0],  # [t_last, elapsed, eta, sps, done_last, rendered, printed_lines]
                             width: int = 99, divisions: int = 20,
                             min_interval: float = 0.5, _last_print=[0.0]):
    """
    5줄 블록(상/바/통계/인덱스/하) 출력.
    - current tile 라인은 새 인덱스가 오기 전까지 이전 값을 계속 보여줍니다.
    - 인덱스는 ETA가 있는 왼쪽 칼럼의 오른쪽 파이프에 맞춰 우측 정렬됩니다.
    """
    import sys, time

    MIN_LEFT   = 8
    BASE_RIGHT = 8  # 퍼센트 칼럼 고정 폭

    # pad/trim 유틸
    def _fit(s: str, w: int, *, right=False):
        if len(s) > w: s = s[:w]
        return s.rjust(w) if right else s.ljust(w)

    def _fmt(sec: float) -> str:
        return _fmt_ddhhmmss(sec)

    # 상태 초기화 (+ last_idx_raw 캐시 추가: state[7])
    now = time.perf_counter()
    if state[0] is None:
        state[0] = now; state[1] = 0.0; state[2] = 0.0
        state[3] = 0.0; state[4] = done
        state[5] = False; state[6] = 0
    if len(state) < 8:
        state.append(None)             # state[7] = last_idx_raw

    # 출력 빈도 제한
    if (now - _last_print[0] < min_interval) and (done < total):
        return None
    _last_print[0] = now

    # 진행률/시간
    pct = 1.0 if total <= 0 else (done / max(1, total))
    if (now - state[0] >= 2.0) or (done >= total):
        elapsed = now - t0
        eta = (elapsed / pct - elapsed) if pct > 0 else 0.0
        state[0], state[1], state[2] = now, elapsed, eta
        state[3] = done / max(1e-9, elapsed)

    elapsed = state[1]; eta = state[2]
    sps     = state[3] if state[3] > 0 else (done / max(1e-9, now - t0))
    eltxt   = _fmt(elapsed); etatxt = _fmt(eta)

    # 텍스트
    pct_txt = f"{pct*100:6.2f}%"
    # 새 인덱스가 오면 업데이트, 없으면 기존 캐시(state[7]) 유지
    if cur_i is not None:
        state[7] = (f"last processed tile: x[{cur_i}]...y[{cur_j0}:{cur_j1}]"
                    if (cur_j0 is not None and cur_j1 is not None)
                    else f"last processed tile: x[{cur_i}]")
    idx_raw = state[7] or ""  # 캐시 사용

    stats_text = " | ".join([
        f" {done}/{total} profiles",
        f"{sps:5.2f} profiles/s",
        f"elapsed {eltxt}",
        f"eta {etatxt}",
    ])

    # 폭/칼럼

    inner_w = max(20, width - 2)
    right_w = BASE_RIGHT
    left_w  = inner_w - 3 - right_w

    need_inner = max(len(stats_text), MIN_LEFT) + 3 + right_w
    if inner_w < need_inner:
        inner_w = need_inner; width = inner_w + 2; left_w = inner_w - 3 - right_w
    if left_w < MIN_LEFT:
        grow = MIN_LEFT - left_w
        inner_w += grow; width += grow; left_w = MIN_LEFT
    border = "|" + "-" * inner_w + "|"

    # 2) 바
    groups = max(1, left_w // 4)
    filled = int(groups * pct + 1e-12)
    tokens = (["---:"] * max(0, filled - 1)) + (["--> "] if filled > 0 else []) + (["  : "] * (groups - filled))
    bar_left = _fit("".join(tokens), left_w)
    line2 = "|" + bar_left + " | " + _fit(pct_txt, right_w, right=True) + " |"

    # 3) 통계
    line3 = "|" + _fit(stats_text, left_w) + " | " + _fit("", right_w, right=True) + " |"

    # 4) current tile (왼쪽 칼럼에 우측 정렬, 길면 앞을 '...'로 접기)
    if idx_raw and len(idx_raw) > left_w:
        idx_show = ("..." + idx_raw[-(left_w - 3):]) if left_w > 3 else idx_raw[-left_w:]
    else:
        idx_show = idx_raw
    line4 = "|" + _fit(idx_show, left_w, right=True) + " | " + _fit("", right_w, right=True) + " |"

    # 출력 (덮어쓰기)
    def _out(line: str):
        if len(line) < width: line = line + (" " * (width - len(line)))
        elif len(line) > width: line = line[:width]
        sys.stdout.write("\r" + line + "\x1b[0K\n")


    if state[5] and state[6] == 5:
        sys.stdout.write("\x1b[5A")
    _out(border); _out(line2); _out(line3); _out(line4); _out(border)
    sys.stdout.flush()

    state[5] = True; state[6] = 5
    return line2







def _print_progress_classic1(done: int, total: int, t0: float,
                             cur_i=None, cur_j0=None, cur_j1=None,
                             state=[None, 0.0, 0.0, 0.0, 0, False, 0],  # [t_last, elapsed, eta, sps, done_last, rendered, printed_lines]
                             width: int = 99, divisions: int = 20,
                             min_interval: float = 0.5, _last_print=[0.0],
                             safe_margin: int = 1):
    """
    5줄 블록(상/바/통계/인덱스/하)을 고정 폭으로 출력.
    - 맨 끝 열 자동 줄바꿈 문제를 피하기 위해 safe_margin(기본 1칸)만큼 오른쪽 여유를 둡니다.
      => 실제 출력 폭 = width - safe_margin (맨 오른쪽 칸은 비워둠)
    - 'last processed tile' 라인은 새 값이 들어오기 전까지 이전 값을 유지(state[7] 캐시).
    - 인덱스 라인은 ETA가 있는 왼쪽 칼럼의 오른쪽 파이프에 맞춰 우측 정렬됩니다.
    """
    import sys, time

    MIN_LEFT   = 8      # 바(왼쪽 칼럼) 최소 폭
    BASE_RIGHT = 12     # 퍼센트 칼럼(오른쪽) 고정 폭

    # pad/trim 유틸
    def _fit(s: str, w: int, *, right=False):
        if len(s) > w: s = s[:w]
        return s.rjust(w) if right else s.ljust(w)

    def _fmt(sec: float) -> str:
        return _fmt_ddhhmmss(sec)

    # 상태 초기화 (+ last_idx_raw 캐시: state[7])
    now = time.perf_counter()
    if state[0] is None:
        state[0] = now; state[1] = 0.0; state[2] = 0.0
        state[3] = 0.0; state[4] = done
        state[5] = False; state[6] = 0
    if len(state) < 8:
        state.append(None)  # state[7] = last_idx_raw

    # 출력 빈도 제한
    if (now - _last_print[0] < min_interval) and (done < total):
        return None
    _last_print[0] = now

    # 진행률/시간
    pct = 1.0 if total <= 0 else (done / max(1, total))
    if (now - state[0] >= 2.0) or (done >= total):
        elapsed = now - t0
        eta = (elapsed / pct - elapsed) if pct > 0 else 0.0
        state[0], state[1], state[2] = now, elapsed, eta
        state[3] = done / max(1e-9, elapsed)

    elapsed = state[1]; eta = state[2]
    sps     = state[3] if state[3] > 0 else (done / max(1e-9, now - t0))
    eltxt   = _fmt(elapsed); etatxt = _fmt(eta)

    # 텍스트 구성
    pct_txt = f"{pct*100:6.2f}%"
    if cur_i is not None:
        state[7] = (f"last processed tile: x[{cur_i}]...y[{cur_j0}:{cur_j1}]"
                    if (cur_j0 is not None and cur_j1 is not None)
                    else f"last processed tile: x[{cur_i}]")
    idx_raw = state[7] or ""

    stats_text = " | ".join([
        f"{done}/{total} profiles",
        f"{sps:5.2f} profiles/s",
        f"elapsed {eltxt}",
        f"eta {etatxt}",
    ])

    # ===== 안전 폭 계산 (맨 끝 1칸 남기기) =====
    print_w  = max(30, width - max(0, safe_margin))  # 실제로 화면에 깔리는 폭
    inner_w  = print_w - 2                           # 파이프 제외 내부 폭
    right_w  = BASE_RIGHT
    left_w   = inner_w - 3 - right_w

    # 통계 줄이 왼쪽 칼럼에 들어가도록 최소 보장(넘치면 print_w가 줄기 때문에 잘릴 수 있음)
    need_inner = max(len(stats_text), MIN_LEFT) + 3 + right_w
    if inner_w < need_inner:
        # 왼쪽 칼럼이 부족하면 통계 텍스트가 잘릴 수 있지만, print_w는 유지(오른쪽 | 보이기 우선)
        left_w = max(MIN_LEFT, inner_w - 3 - right_w)

    border = "|" + "-" * inner_w + "|"

    # 2) 진행 바 (왼쪽 칼럼)
    groups = max(1, left_w // 4)
    filled = int(groups * pct + 1e-12)
    tokens = (["---:"] * max(0, filled - 1)) + (["--> "] if filled > 0 else []) + (["  : "] * (groups - filled))
    bar_left = _fit("".join(tokens), left_w)
    line2 = "|" + bar_left + " | " + _fit(pct_txt, right_w, right=True) + " |"

    # 3) 통계
    line3 = "|" + _fit(stats_text, left_w) + " | " + _fit("", right_w, right=True) + " |"

    # 4) 인덱스(왼쪽 칼럼 끝에 우측 정렬, 새 값 올 때까지 캐시 유지)
    if idx_raw and len(idx_raw) > left_w:
        idx_show = ("..." + idx_raw[-(left_w - 3):]) if left_w > 3 else idx_raw[-left_w:]
    else:
        idx_show = idx_raw
    line4 = "|" + _fit(idx_show, left_w, right=True) + " | " + _fit("", right_w, right=True) + " |"

    # 안전 출력(각 줄을 정확히 print_w로 맞추고, 라인 끝 잔여 지우기)
    def _out(line: str):
        if len(line) < print_w: line = line + (" " * (print_w - len(line)))
        elif len(line) > print_w: line = line[:print_w]
        sys.stdout.write("\r" + line + "\x1b[0K\n")

    # 이미 그려졌다면 5줄 위로 이동 후 덮어쓰기
    if state[5] and state[6] == 5:
        sys.stdout.write("\x1b[5A")
    _out(border); _out(line2); _out(line3); _out(line4); _out(border)
    sys.stdout.flush()

    state[5] = True; state[6] = 5
    return line2








def _print_progress_classic0(done: int, total: int, t0: float,
                            cur_i=None, cur_j0=None, cur_j1=None,
                            state=[None, 0.0, 0.0, 0.0, 0, 0, False],  # [t_last, elapsed, eta, sps, done_at_last, ticks, rendered]
                            width: int = 80, divisions: int = 20,
                            min_interval: float = 1.0, _last_print=[0.0]):
    """
    진행 상황을 다음과 같은 5줄 블록으로 갱신합니다.
    |-------------------------------------------------------------------------------|
    |---:--:--:--:--:--:--:--:--:--:--:--:--:-->  :  :  :  :  :   |          73.75% |
    | 1180/1600 profiles |  3.72 profiles/s | elapsed 00:00:05:17 | eta 00:00:01:53 |
    |                                       |         current tile: x[19]...y[0:20] |
    |-------------------------------------------------------------------------------|
    """

    import sys, time

    PERC_FIELD = 12  # 우측 퍼센트/인덱스 칼럼 폭(예시처럼 넉넉하게)

    def _render_bar_line(pct: float, inner_width: int) -> tuple[str, int]:
        """
        2번째 줄 반환 + 분할 위치(left_len) 반환.
        포맷: | <bar_left (left_len)> | <percent rjust(PERC_FIELD)> |
        bar_left는 4문자 그룹:
          채워짐 '---:', 진행 '--> ', 비움 '  : '
        """
        left_len = inner_width - 3 - PERC_FIELD
        left_len = max(8, left_len)

        groups = max(1, left_len // 4)             # 4문자 단위 그룹 수
        fill_groups = int(groups * pct + 1e-12)

        tokens = []
        if fill_groups > 0:
            if fill_groups >= 1:
                tokens += ["---:"] * (fill_groups - 1)
                tokens += ["--> "]
        empty_groups = groups - fill_groups
        if empty_groups > 0:
            tokens += ["  : "] * empty_groups

        bar_left = "".join(tokens)
        # 길이 보정
        if len(bar_left) < left_len:
            bar_left += " " * (left_len - len(bar_left))
        elif len(bar_left) > left_len:
            bar_left = bar_left[:left_len]

        pct_txt = f"{pct*100:6.2f}%  |".rjust(PERC_FIELD)
        line = f"|{bar_left} | {pct_txt} |"
        return line, left_len

    def _render_stats_line(done: int, total: int, sps: float,
                           elapsed_txt: str, eta_txt: str,
                           inner_width: int) -> str:
        parts = [
            f"{done}/{total} profiles",
            f"{sps:5.2f} profiles/s",
            f"elapsed {elapsed_txt}",
            f"eta {eta_txt}",
        ]
        line = "| " + " | ".join(parts) + " |"
        # 내부 폭에 맞춰 패딩/자름
        content_len = len(line) - 2
        if content_len < inner_width:
            line = line[:-1] + " " * (inner_width - content_len) + "|"
        elif content_len > inner_width:
            line = "|" + line[1:1+inner_width] + "|"
        return line

    def _render_index_line(left_len: int, inner_width: int) -> str:
        # 우측 칼럼: PERC_FIELD 폭 안에서 우측 정렬
        if cur_i is None:
            right_txt = ""
        else:
            if (cur_j0 is not None) and (cur_j1 is not None):
                right_txt = f"current tile: x[{cur_i}]...y[{cur_j0}:{cur_j1}]"
            else:
                right_txt = f"current tile: x[{cur_i}]"
        if len(right_txt) > PERC_FIELD:
            # 우측 정렬 유지 위해 뒤쪽을 보존(세부값 유지)
            right_txt = right_txt[-PERC_FIELD:]
        right_col = right_txt.rjust(PERC_FIELD)
        return f"|{' ' * left_len} | {right_col} |"

    now = time.perf_counter()
    if state[0] is None:
        state[0] = now     # t_last (ETA/경과 갱신 기준)
        state[1] = 0.0     # elapsed
        state[2] = 0.0     # eta
        state[3] = 0.0     # sps
        state[4] = done    # done_at_last
        # 확장 상태: [7]=lines_printed
        while len(state) < 8:
            state.append(0)
        state[6] = False   # rendered 여부
        state[7] = 0       # lines_printed

    # 너무 잦은 출력 제한
    if (now - _last_print[0] < min_interval) and (done < total):
        return None
    _last_print[0] = now

    pct = 1.0 if total <= 0 else (done / max(1, total))

    # 경과/ETA는 2초마다 갱신(또는 완료 시)
    if (now - state[0] >= 2.0) or (done >= total):
        elapsed = now - t0
        eta = (elapsed / pct - elapsed) if pct > 0 else 0.0
        state[0] = now
        state[1] = elapsed
        state[2] = eta
        state[3] = done / max(1e-9, elapsed)

    elapsed = state[1]
    eta     = state[2]
    sps     = state[3] if state[3] > 0 else (done / max(1e-9, now - t0))

    inner_width = max(20, width - 2)  # 파이프 제외 내부 폭
    border = "|" + ("-" * inner_width) + "|"

    # 각 라인 렌더
    bar_line, left_len = _render_bar_line(pct, inner_width)
    elapsed_txt = _fmt_ddhhmmss(elapsed)
    eta_txt     = _fmt_ddhhmmss(eta)
    stats_line  = _render_stats_line(done, total, sps, elapsed_txt, eta_txt, inner_width)
    index_line  = _render_index_line(left_len, inner_width)

    # 이미 출력된 블록이 있으면 5줄 위로 이동 후 덮어쓰기
    if state[6] and state[7] == 5:
        sys.stdout.write("\x1b[5A")

    block = border + "\n" + bar_line + "\n" + stats_line + "\n" + index_line + "\n" + border + "\n"
    sys.stdout.write(block)
    sys.stdout.flush()

    state[6] = True
    state[7] = 5
    return bar_line
